# Gummy Bears

An interactive bowl of translucent jelly bears: grab, stretch, squash, throw, pour, wobble, set off fireworks — or load one into the little glass cannon and fire it across the table. Rendered with **three.js**; soft-body physics runs on **Box3D** (erincatto/box3d) compiled to WebAssembly.

## Launch it

Double-click the launcher for your system:

| System | File |
| --- | --- |
| macOS | **Launch Gummy Bears.command** |
| Windows | **Launch Gummy Bears.bat** |
| Linux | **launch-gummy-bears.sh** (or `python3 launch.py --install-shortcut`) |

Every launcher runs `launch.py`, which needs **Python 3** (already present on macOS/Linux; install it from python.org on Windows). On first launch, allow Python through the firewall (macOS and Windows both prompt) if you want to open the app from other devices.

The host opens **http://localhost:8000/**. The launcher also listens on the local network and prints a second **Network** URL such as `http://192.168.1.23:8000/` — open that on a phone or another computer on the same Wi-Fi/LAN. Use `--localhost` to restrict access to the host machine only, or `--port 8080` to change the port:

```bash
python3 launch.py              # localhost + network
python3 launch.py --localhost  # this machine only
python3 launch.py --port 8080
python3 launch.py --no-open
```

If the executable bits were lost (for example after unzipping on Windows), restore them on macOS/Linux with:

```bash
chmod +x launch.py "Launch Gummy Bears.command" launch-gummy-bears.sh
```

You can also run it by hand:

```bash
python3 launch.py
```

The app uses ES modules and a `.wasm` file, so it must be served over HTTP (opening `index.html` via `file://` will not load the physics). The previous single-file version is preserved as [`legacy-singlefile.html`](legacy-singlefile.html) and works directly from disk.

## Controls

- **Grab** a bear with the left mouse button (or a finger) and pull to stretch; release to throw. Multiple pointers can grab at once.
- **Orbit** by dragging empty space, right-dragging, or two-finger dragging. **Pan** with middle-drag, shift-drag, or two-finger drag. **Zoom** with the wheel or pinch. `WASD` pan, `Q`/`E` orbit, `R` resets the camera.
- **F** fires a firework at the cursor, hold to spray, `Shift+F` fans; the EXPLODE button fires a volley. `?` opens the controls sheet.
- **L / Launch bear** arms the glass cannon. Aim with the mouse (or drag a finger) and release/click to fire a bear on a ballistic arc; `Esc` or the button cancels. The landing ring shows where it will come down.
- Flavor swatches, custom color + clarity, wobble, bear ceiling (8–256, persisted), upright assist, pour, reset, and a performance overlay.

## Layout

```
index.html                 page shell, styles, HUD
launch.py                  cross-platform local/LAN server + browser launcher
Launch Gummy Bears.command macOS double-click launcher
Launch Gummy Bears.bat     Windows double-click launcher
launch-gummy-bears.sh      Linux launcher
src/app.js                 renderer, metaball surface, input, UI, cannon, fireworks, loop
src/config.js              flavors + the 24-body bear rig
src/box3d.js               JS side of the physics bridge (batched calls)
scripts/box3d_wrapper.c    C wrapper: world, spheres, statics, spring joints
scripts/build-box3d.sh     reproducible Box3D + wrapper wasm build
vendor/box3d/              prebuilt box3d.js / box3d.wasm + MIT license
legacy-singlefile.html     previous single-file build (custom point physics)
```

## How the bear is simulated

Each bear is **24 sphere bodies with rotation locked** (so the jelly solver only has to drive translations). Box3D owns contacts, friction, CCD and sleep. Our solver adds the jelly every 60 Hz step:

- mass-weighted **shape matching** to a rest pose (polar decomposition, capped tracking),
- **volume preservation** that bulges sideways when compressed,
- COM-relative damping, grab springs per pointer, and a press-squash,
- an **upright** torque plus a gentle righting nudge that yields to pushes,
- **distance-spring joints** for the spine, ears/snout, arms, legs and cross-braces,
- negative collision groups so a bear's own parts never self-collide.

The render surface is a metaball field (spheres + neck/arm/leg capsules) polygonised with surface nets on a deformation-gated lattice; rigid mesh reprojection keeps motion smooth between rebuilds. Box3D contact tuning is deliberately soft (55 Hz, 0.72 damping).

The **bear launcher** is a small glass-and-brass cannon at the table edge. Entering aim mode solves a ballistic launch (fixed 32° elevation, cursor-targeted speed) and draws a dotted arc plus a landing ring; firing spawns a new 24-body bear lying head-first along the barrel with the solved velocity. The cannon itself is visual-only, so bears never catch on it.

## Rebuilding the physics wasm

Requires cmake + Emscripten (tested with cmake 4.4.4, emcc 6.0.12):

```bash
brew install cmake emscripten
./scripts/build-box3d.sh
```

This pins **Box3D v0.1.0** and builds single-threaded wasm with SIMD (`-msimd128`), so no COOP/COEP headers are needed. The prebuilt module is checked in, so the toolchain is only needed when changing the wrapper.

## Performance

Measured headless in Chrome on Apple silicon (CPU frame cost; surface time varies with grid tier + rebuild rate):

| bears | bodies | physics | surface | total |
|------:|-------:|--------:|--------:|------:|
| 21 | 504 | ~0.8 ms | ~6.6 ms | ~7.4 ms |
| 128 | 3,072 | ~8.3 ms | ~3 ms | ~11.3 ms |

The 256 ceiling is available (6,144 bodies) but heavy; the crowd tiers reduce surface detail as the count rises. GPU transmission is the other big cost at high DPR; the quality tiers adjust for it.

## Verification

The Box3D port passes a 16-check headless self-test covering NaN/bounds, bounce counting, pour, head pull/stretch readout, upright hang, press squash, snap-back, throws, release launch, surface validity, vertex limits and the bear ceiling. Separate checks drive the cannon through the UI, the keyboard (`L`/`Esc`), the debug API and real mouse events. Visual beats cover solo views, pull, pancake, pile, faces, aiming/firing, aspect ratios, fireworks and performance.

## Known limitations

- Physics play bounds are created from the table size at load; resizing the window updates the camera/table visuals but not the invisible Box3D walls.
- The launcher listens on the LAN by default (so phones can join). Use `python3 launch.py --localhost` on untrusted networks.
- The surface pipeline is CPU-bound; very large crowds deliberately drop metaball resolution.
- Box3D v0.1.0 is young; the wrapper only exposes the subset this app needs.
